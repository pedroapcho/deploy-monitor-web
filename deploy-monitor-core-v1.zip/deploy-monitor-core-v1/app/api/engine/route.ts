import { NextResponse } from 'next/server';
import { readAllowedFiles } from '@/lib/github';
import { generateChanges } from '@/lib/agent';

export async function POST(req: Request) {
  try {
    const { instruction } = await req.json();

    if (!instruction) {
      return NextResponse.json({ error: 'Falta instruction' }, { status: 400 });
    }

    const repoFiles = await readAllowedFiles();
    const result = await generateChanges(instruction, repoFiles);

    return NextResponse.json({
      ok: true,
      status: 'Propuesta generada',
      scannedFiles: repoFiles.map((file) => ({
        path: file.path,
        chars: file.content.length
      })),
      result
    });
  } catch (error: any) {
    return NextResponse.json({
      ok: false,
      error: error.message || 'Error en motor'
    }, { status: 500 });
  }
}
