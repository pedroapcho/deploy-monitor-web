import { NextResponse } from 'next/server';
import { updateGithubFiles } from '@/lib/github';

export async function POST(req: Request) {
  try {
    const { files, message } = await req.json();

    if (!Array.isArray(files) || files.length === 0) {
      return NextResponse.json({ error: 'No hay archivos para aplicar' }, { status: 400 });
    }

    const result = await updateGithubFiles(files, message || 'Deploy Monitor Core update');

    return NextResponse.json({
      ok: true,
      status: 'GitHub actualizado',
      result
    });
  } catch (error: any) {
    return NextResponse.json({
      ok: false,
      error: error.message || 'Error aplicando cambios'
    }, { status: 500 });
  }
}
