import { NextResponse } from 'next/server';
import { triggerDeploy } from '@/lib/vercel';

export async function POST() {
  try {
    const result = await triggerDeploy();

    return NextResponse.json({
      ok: true,
      status: 'Deploy disparado',
      result
    });
  } catch (error: any) {
    return NextResponse.json({
      ok: false,
      error: error.message || 'Error disparando deploy'
    }, { status: 500 });
  }
}
