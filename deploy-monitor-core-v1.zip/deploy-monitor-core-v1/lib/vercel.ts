export async function triggerDeploy() {
  const hook = process.env.VERCEL_DEPLOY_HOOK_URL;

  if (!hook) {
    throw new Error('Falta VERCEL_DEPLOY_HOOK_URL.');
  }

  const res = await fetch(hook, { method: 'POST' });

  if (!res.ok) {
    throw new Error(`Deploy hook falló con status ${res.status}`);
  }

  return { ok: true, status: res.status };
}
