import OpenAI from 'openai';
import { AgentResult, RepoFile } from './types';

function extractJson(text: string) {
  const first = text.indexOf('{');
  const last = text.lastIndexOf('}');
  if (first === -1 || last === -1) {
    throw new Error('La IA no devolvió JSON válido.');
  }
  return JSON.parse(text.slice(first, last + 1));
}

export async function generateChanges(instruction: string, repoFiles: RepoFile[]): Promise<AgentResult> {
  if (!process.env.OPENAI_API_KEY) {
    return {
      summary: 'Modo demo: falta OPENAI_API_KEY.',
      steps: [
        'Leer archivos permitidos desde GitHub',
        'Enviar contexto a OpenAI',
        'Generar propuesta',
        'Esperar aprobación',
      ],
      files: [],
      warnings: ['Agrega OPENAI_API_KEY para activar el motor real.']
    };
  }

  const allowed = repoFiles.map((file) => file.path);
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

  const context = repoFiles.map((file) => {
    return `--- FILE: ${file.path} ---\n${file.content}`;
  }).join('\n\n');

  const prompt = `
Eres el motor de Deploy Monitor AI.
Tu tarea es modificar una web/app según la instrucción del usuario.

Devuelve SOLO JSON válido con esta forma:
{
  "summary": "resumen corto",
  "steps": ["paso 1", "paso 2"],
  "files": [
    { "path": "archivo permitido", "content": "contenido completo actualizado" }
  ],
  "warnings": []
}

Reglas:
- Solo puedes modificar estos archivos: ${allowed.join(', ')}
- Devuelve archivos completos, no patches.
- No uses markdown.
- No inventes secretos ni credenciales.
- Si no hay suficiente contexto, devuelve files: [] y explica en warnings.
- Mantén la app compilable.

Instrucción:
${instruction}

Contexto del proyecto:
${context}
`;

  const response = await client.responses.create({
    model: 'gpt-4.1',
    input: prompt
  });

  const parsed = extractJson(response.output_text || '{}');

  const files = Array.isArray(parsed.files)
    ? parsed.files.filter((file: any) => allowed.includes(file.path) && typeof file.content === 'string')
    : [];

  return {
    summary: parsed.summary || 'Cambios generados',
    steps: Array.isArray(parsed.steps) ? parsed.steps : [],
    files,
    warnings: Array.isArray(parsed.warnings) ? parsed.warnings : []
  };
}
