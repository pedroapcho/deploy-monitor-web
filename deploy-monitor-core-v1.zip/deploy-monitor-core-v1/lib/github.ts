import { Octokit } from '@octokit/rest';
import { ChangeFile, RepoFile } from './types';

function config() {
  const token = process.env.GITHUB_TOKEN;
  const owner = process.env.GITHUB_OWNER;
  const repo = process.env.GITHUB_REPO;
  const branch = process.env.GITHUB_BRANCH || 'main';
  const allowedFiles = (process.env.ALLOWED_FILES || '')
    .split(',')
    .map((x) => x.trim())
    .filter(Boolean);

  if (!token || !owner || !repo) {
    throw new Error('Faltan variables de GitHub.');
  }

  if (allowedFiles.length === 0) {
    throw new Error('ALLOWED_FILES está vacío.');
  }

  return { token, owner, repo, branch, allowedFiles };
}

export async function getRepoStatus() {
  const { owner, repo, branch, allowedFiles } = config();
  return { owner, repo, branch, allowedFiles };
}

export async function readAllowedFiles(): Promise<RepoFile[]> {
  const { token, owner, repo, branch, allowedFiles } = config();
  const octokit = new Octokit({ auth: token });
  const files: RepoFile[] = [];

  for (const path of allowedFiles) {
    try {
      const current = await octokit.repos.getContent({ owner, repo, path, ref: branch });

      if (!Array.isArray(current.data) && 'content' in current.data) {
        files.push({
          path,
          content: Buffer.from(current.data.content || '', 'base64').toString('utf8')
        });
      }
    } catch {
      files.push({ path, content: '' });
    }
  }

  return files;
}

export async function updateGithubFiles(files: ChangeFile[], message: string) {
  const { token, owner, repo, branch, allowedFiles } = config();
  const octokit = new Octokit({ auth: token });
  const results = [];

  for (const file of files) {
    if (!allowedFiles.includes(file.path)) {
      throw new Error(`Archivo no permitido: ${file.path}`);
    }

    let sha: string | undefined;

    try {
      const current = await octokit.repos.getContent({ owner, repo, path: file.path, ref: branch });
      if (!Array.isArray(current.data) && 'sha' in current.data) {
        sha = current.data.sha;
      }
    } catch {
      sha = undefined;
    }

    const updated = await octokit.repos.createOrUpdateFileContents({
      owner,
      repo,
      path: file.path,
      message,
      content: Buffer.from(file.content, 'utf8').toString('base64'),
      branch,
      sha
    });

    results.push({
      path: file.path,
      commit: updated.data.commit.sha
    });
  }

  return results;
}
