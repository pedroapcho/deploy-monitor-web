export type RepoFile = {
  path: string;
  content: string;
};

export type ChangeFile = {
  path: string;
  content: string;
};

export type AgentResult = {
  summary: string;
  steps: string[];
  files: ChangeFile[];
  warnings?: string[];
};
